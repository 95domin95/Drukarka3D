﻿window.addEventListener("load", function () {

    var loginIcon = document.getElementById("login-icon");

    var loginForm = document.getElementById("login-form");

    loginIcon.innerHTML = "";
    loginForm.innerHTML = "";

}, false);